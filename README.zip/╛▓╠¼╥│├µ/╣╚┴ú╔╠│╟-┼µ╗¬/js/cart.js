let cartDate = {
    goods: [
        {
            goodImg: "./images/goods1.png",
            goodTitle: "米家（MIJIA） 小米小白智能摄像机增强版 1080p高清360度全景拍摄AI增强",
            goodTxt: "语音升级款",
            goodPrice: "399.00",
            goodNum: 1,
        },
        {
            goodImg: "./images/goods2.png",
            goodTitle: "华为（MIJIA） 华为metaPRO 30 浴霸4摄像 超清晰",
            goodTxt: "黑色版本",
            goodPrice: "5622.00",
            goodNum: 1,
        },
        {
            goodImg: "./images/goods3.png",
            goodTitle: "iphone 11 max PRO 苹果四摄 超清晰 超费电 超及好用",
            goodTxt: "墨绿色",
            goodPrice: "11399.00",
            goodNum: 1,
        }

    ]
}