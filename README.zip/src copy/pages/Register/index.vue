<template>
  <div>register</div>  
</template>

<script>
export default {
name:"Register"
}
</script>


<style lang="less" scoped>

</style>