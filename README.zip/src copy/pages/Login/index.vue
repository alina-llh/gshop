<template>
  <div>login</div>  
</template>

<script>
export default {
name:"Login"
}
</script>


<style lang="less" scoped>

</style>