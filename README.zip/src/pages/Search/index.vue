<template>
  <div>
    search
    query:{{keywrod1}},
    params:{{keywrod}}
  </div>
</template>

<script>
export default {
  name: 'Search',
  props: ['keywrod1', 'keywrod']
}
</script>

<style>
</style>